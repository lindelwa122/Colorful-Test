class SkipTest(Exception):
    pass