class SkipTest(Exception):
    """A SkipTest exception. Raised when skipping a test."""
    pass
